# FLR Visuals 1.2.1 (NeoForge 1.21.1)

Исходники: `src/main/java/dev/flr/visuals/` (переписаны CosmeticsScreen и CosmeticsLayer).
Остальные классы и ассеты берутся из `libs/flrvisuals-1_2_0.jar` без изменений.

## Сборка
1. JDK 21.
2. Gradle wrapper: скопируй `gradlew`, `gradlew.bat` и папку `gradle/` из NeoForge MDK для 1.21.1 в корень проекта (или выполни `gradle wrapper`).
3. Проверь `neo_version` в `gradle.properties` и версию плагина `net.neoforged.moddev` в `build.gradle` по MDK.
4. `./gradlew build` → джар в `build/libs/flrvisuals-1.2.1.jar`.
5. Тест в клиенте: `./gradlew runClient`.

## Что проверить после первой сборки
- Крылья: не вывернуты ли они (направление "назад" = +z).
- Меню открывается, переключатели и слайдеры плавные, закругления не ломаются.
- Конфиг `flrvisuals.properties` сохраняется после изменений.

См. CHANGES.md.
